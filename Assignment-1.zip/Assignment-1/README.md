Website to refer ->
https://preview.colorlib.com/#sogo
//You need to build a page like Sample.jgp in images folder
Please dont change any code on index.html
